<template>
  <div class="min-h-screen flex flex-col bg-gray-50">
    <!-- HEADER -->
    <NavbarStudent />

    <!-- ISI DASHBOARD -->
    <main class="flex-1 py-8 px-6">
      <div class="max-w-6xl mx-auto flex gap-6">

        <!-- ===== KIRI: Paket, Progress, Jadwal ===== -->
        <div class="flex-[2] space-y-6">
          <!-- Paket Belajar -->
          <section class="bg-white rounded-2xl shadow p-6">
            <h2 class="text-xl font-semibold text-sky-700 mb-4">Paket Belajar</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div
                v-for="(pkg, index) in packages"
                :key="index"
                class="border rounded-xl p-4 shadow-sm hover:shadow-md transition"
              >
                <h3 class="font-semibold mb-2">{{ pkg.title }}</h3>
                <p class="text-gray-600 text-sm mb-2">
                  Rp {{ pkg.price.toLocaleString() }}
                </p>
                <ul class="text-sm text-gray-500 space-y-1">
                  <li v-for="(item, i) in pkg.features" :key="i">✔ {{ item }}</li>
                </ul>
                <button
                  class="mt-4 w-full bg-sky-600 text-white py-1.5 rounded-md hover:bg-sky-700 transition"
                >
                  Pilih Paket
                </button>
              </div>
            </div>
          </section>

          <!-- Progress Belajar -->
          <section class="bg-white rounded-2xl shadow p-6">
            <h2 class="text-xl font-semibold text-sky-700 mb-3">Progress Belajar</h2>
            <p class="text-sm text-gray-600 mb-2">Sisa Pertemuan</p>
            <div class="w-full bg-gray-200 rounded-full h-3">
              <div
                class="bg-sky-600 h-3 rounded-full transition-all duration-500"
                :style="{ width: progress + '%' }"
              ></div>
            </div>
          </section>

          <!-- Jadwal Belajar -->
          <section class="bg-white rounded-2xl shadow p-6">
            <h2 class="text-xl font-semibold text-sky-700 mb-3">Jadwal Belajar</h2>
            <div class="text-gray-600 text-sm">
              <div
                v-for="(jadwal, index) in jadwalList"
                :key="index"
                class="border rounded-lg p-3 mb-2 flex justify-between"
              >
                <span>{{ jadwal.matkul }}</span>
                <span>{{ jadwal.waktu }}</span>
              </div>
            </div>
          </section>
        </div>

        <!-- ===== KANAN: Tutor Rekomendasi (scroll terpisah) ===== -->
        <div class="flex-1">
          <section class="bg-white rounded-2xl shadow p-6 h-[80vh] overflow-y-auto">
            <h2 class="text-xl font-semibold text-sky-700 mb-4">Rekomendasi Tutor</h2>
            <div
              v-for="(tutor, index) in tutors"
              :key="index"
              class="border rounded-xl p-4 mb-3 shadow-sm hover:shadow-md transition"
            >
              <div class="flex items-center gap-3 mb-2">
                <div class="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div>
                  <h3 class="font-semibold text-gray-800">{{ tutor.name }}</h3>
                  <p class="text-sm text-gray-500">{{ tutor.subject }}</p>
                </div>
              </div>
              <p class="text-xs text-gray-500 mb-2">
                {{ tutor.description }}
              </p>
              <div class="text-sm text-gray-600">
                ⭐ {{ tutor.rating }} • {{ tutor.level }}
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>

    <!-- FOOTER -->
    <FooterStudent />
  </div>
</template>

<script setup>
import NavbarStudent from '@/components/layout/navbarStudent.vue'
import FooterStudent from '@/components/layout/footer.vue'

const packages = [
  {
    title: '4 Pertemuan',
    price: 200000,
    features: ['Materi lengkap', 'Konsultasi tutor', 'Akses jadwal fleksibel'],
  },
  {
    title: '8 Pertemuan',
    price: 350000,
    features: ['Materi lengkap', 'Konsultasi tutor', 'Bonus kuis interaktif'],
  },
  {
    title: '12 Pertemuan',
    price: 500000,
    features: ['Materi lengkap', 'Konsultasi tutor', 'Ujian simulasi akhir'],
  },
]

const progress = 60

const jadwalList = [
  { matkul: 'Matematika', waktu: 'Senin, 08:00 - 09:30' },
  { matkul: 'Fisika', waktu: 'Rabu, 10:00 - 11:30' },
]

const tutors = [
  {
    name: 'Budi Santoso',
    subject: 'Matematika',
    rating: '4.9',
    level: 'SMP & SMA',
    description: 'Tutor berpengalaman lebih dari 5 tahun mengajar.',
  },
  {
    name: 'Sinta Dewi',
    subject: 'Fisika',
    rating: '4.8',
    level: 'SMA',
    description: 'Menguasai konsep fisika modern dan eksperimental.',
  },
  {
    name: 'Dimas Pratama',
    subject: 'Kimia',
    rating: '4.7',
    level: 'SMA',
    description: 'Tutor bersertifikat, sabar dan komunikatif.',
  },
  {
    name: 'Ayu Lestari',
    subject: 'Bahasa Inggris',
    rating: '4.9',
    level: 'SMP',
    description: 'Berpengalaman mengajar grammar dan speaking.',
  },
]
</script>
