<template>
    <div>
        <img src="@/assets/logo.svg" alt="Lazuardy Logo" class="h-10 w-auto" />
    </div>
</template>