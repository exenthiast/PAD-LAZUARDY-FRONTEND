<template>
  <footer class="bg-white border-t mt-auto">
    <div
      class="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row justify-between items-center text-gray-600 text-sm"
    >
      <p>&copy; 2025 Bimbel Lazuardy. Semua hak dilindungi.</p>

      <div class="flex space-x-4 mt-2 sm:mt-0">
        <a href="#" class="hover:text-teal-500 transition">Tentang Kami</a>
        <a href="#" class="hover:text-teal-500 transition">Kebijakan Privasi</a>
        <a href="#" class="hover:text-teal-500 transition">Kontak</a>
      </div>
    </div>
  </footer>
</template>

<script setup>
// ga perlu script dulu
</script>

<style scoped>
footer {
  font-family: 'Inter', sans-serif;
}
</style>
