<template>
  <div>
    <!-- NAVBAR -->
    <header
      :class="[
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        isScrolled ? 'backdrop-blur-md shadow-lg' : 'bg-[#41a6c2] shadow-sm',
      ]"
    >
      <div
        class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between"
      >
        <!-- Left: Hamburger + Logo -->
        <div class="flex items-center gap-3">
          <button
            @click="toggleSidebar"
            class="p-2 rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Menu"
          >
            <svg
              class="w-6 h-6 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
          <img
            src="@/assets/logo.svg"
            alt="Bimbel Lazuardy"
            class="h-8 w-auto"
          />
        </div>

        <!-- Right: Notification + Profile -->
        <div class="flex items-center gap-4">
          <!-- Notification Button -->
          <button
            @click="toggleNotification"
            class="relative p-2 rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Notifications"
          >
            <svg
              class="w-6 h-6 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
              />
            </svg>
            <span
              v-if="notificationCount > 0"
              class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"
            ></span>
          </button>

          <!-- Profile Button -->
          <button
            @click="toggleProfileMenu"
            class="flex items-center gap-2 p-1 rounded-full hover:bg-white/10 transition-colors"
            aria-label="Profile"
          >
            <img
              src="@/assets/profile.jpg"
              alt="Profile"
              class="w-9 h-9 rounded-full border-2 border-white object-cover"
            />
          </button>
        </div>
      </div>
    </header>

    <!-- Spacer -->
    <div class="h-16" aria-hidden="true"></div>

    <!-- SIDEBAR -->
    <transition name="slide-left">
      <div
        v-if="sidebarOpen"
        class="fixed inset-0 z-40 flex"
        @click.self="closeSidebar"
      >
        <div class="fixed inset-0 bg-black/50" @click="closeSidebar"></div>
        <div class="relative w-64 bg-white h-full shadow-xl flex flex-col">
          <div
            class="p-4 border-b flex items-center justify-between bg-[#41a6c2] text-white"
          >
            <h2 class="text-lg font-semibold">Menu</h2>
            <button @click="closeSidebar" class="p-1 hover:bg-white/10 rounded">
              <svg
                class="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>

          <nav class="flex-1 overflow-y-auto p-4">
            <ul class="space-y-2">
              <li v-for="item in menuItems" :key="item.name">
                <a
                  href="#"
                  class="flex items-center gap-3 p-3 rounded-lg hover:bg-[#e0f4f8] transition-colors"
                >
                  <component :is="item.icon" class="w-5 h-5 text-[#41a6c2]" />
                  <span class="font-medium text-gray-700">{{ item.name }}</span>
                </a>
              </li>
            </ul>
          </nav>

          <div class="p-4 border-t">
            <button
              class="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-red-50 text-red-600 transition-colors"
            >
              <svg
                class="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                />
              </svg>
              <span class="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </div>
    </transition>

    <!-- NOTIFICATIONS PANEL -->
    <transition name="slide-right">
      <div
        v-if="notificationOpen"
        class="fixed inset-0 z-40 flex justify-end"
        @click.self="closeNotification"
      >
        <div class="fixed inset-0 bg-black/50" @click="closeNotification"></div>
        <div class="relative w-80 bg-white h-full shadow-xl flex flex-col">
          <div
            class="p-4 border-b flex items-center justify-between bg-[#41a6c2] text-white"
          >
            <h2 class="text-lg font-semibold">Notifikasi</h2>
            <button
              @click="closeNotification"
              class="p-1 hover:bg-white/10 rounded"
            >
              <svg
                class="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
          <div class="flex-1 overflow-y-auto divide-y">
            <div
              v-for="notif in notifications"
              :key="notif.id"
              class="p-4 hover:bg-gray-50 cursor-pointer"
            >
              <div class="flex gap-3">
                <div
                  class="w-10 h-10 bg-[#e0f4f8] rounded-full flex items-center justify-center"
                >
                  <svg
                    class="w-5 h-5 text-[#41a6c2]"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"
                    />
                  </svg>
                </div>
                <div class="flex-1">
                  <p class="text-sm font-medium text-gray-900">
                    {{ notif.title }}
                  </p>
                  <p class="text-sm text-gray-500">{{ notif.message }}</p>
                  <p class="text-xs text-gray-400 mt-1">{{ notif.time }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <!-- PROFILE DROPDOWN -->
    <transition name="fade">
      <div
        v-if="profileMenuOpen"
        class="fixed inset-0 z-30"
        @click="closeProfileMenu"
      >
        <div
          class="absolute top-16 right-4 w-64 bg-white rounded-lg shadow-xl border"
        >
          <div class="p-4 border-b bg-[#f0faff] flex items-center gap-3">
            <img
              src="@/assets/profile.jpg"
              alt="User"
              class="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <p class="font-semibold text-gray-900">John Doe</p>
              <p class="text-sm text-gray-500">john@example.com</p>
            </div>
          </div>

          <div class="py-2">
            <a
              href="#"
              class="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors"
            >
              <svg
                class="w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                />
              </svg>
              <span class="text-gray-700">Profil Saya</span>
            </a>
            <a
              href="#"
              class="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors"
            >
              <svg
                class="w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0"
                />
              </svg>
              <span class="text-gray-700">Pengaturan</span>
            </a>
          </div>

          <div class="border-t py-2">
            <button
              class="w-full flex items-center gap-3 px-4 py-3 hover:bg-red-50 text-red-600 transition-colors"
            >
              <svg
                class="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M17 16l4-4m0 0l-4-4m4 4H7"
                />
              </svg>
              <span class="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from "vue";

// Scroll & state
const isScrolled = ref(false);
const sidebarOpen = ref(false);
const notificationOpen = ref(false);
const profileMenuOpen = ref(false);

// Notifications
const notificationCount = ref(3);
const notifications = ref([
  {
    id: 1,
    title: "Jadwal Belajar Baru",
    message: "Matematika besok jam 14.00",
    time: "5 menit lalu",
  },
  {
    id: 2,
    title: "Pembayaran Berhasil",
    message: "Paket Premium berhasil diproses",
    time: "1 jam lalu",
  },
]);

// Sidebar menu
const menuItems = [
  { name: "Dashboard", icon: "HomeIcon" },
  { name: "Jadwal Belajar", icon: "BookOpenIcon" },
  { name: "Tutor", icon: "UsersIcon" },
  { name: "Paket Belajar", icon: "ArchiveIcon" },
  { name: "Riwayat Pembayaran", icon: "CreditCardIcon" },
];

// Actions
const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
  notificationOpen.value = false;
  profileMenuOpen.value = false;
};
const toggleNotification = () => {
  notificationOpen.value = !notificationOpen.value;
  sidebarOpen.value = false;
  profileMenuOpen.value = false;
  notificationCount.value = 0;
};
const toggleProfileMenu = () => {
  profileMenuOpen.value = !profileMenuOpen.value;
  sidebarOpen.value = false;
  notificationOpen.value = false;
};
const closeSidebar = () => (sidebarOpen.value = false);
const closeNotification = () => (notificationOpen.value = false);
const closeProfileMenu = () => (profileMenuOpen.value = false);
const handleScroll = () => (isScrolled.value = window.scrollY > 20);

onMounted(() => window.addEventListener("scroll", handleScroll));
onBeforeUnmount(() => window.removeEventListener("scroll", handleScroll));
</script>
